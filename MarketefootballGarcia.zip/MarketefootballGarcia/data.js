const akunList = [
  { id: 1, nama: "Akun Legend Squad", harga: "Rp 1.500.000", deskripsi: "Level 25, banyak pemain bintang, GP & koin melimpah.", gambar: "assets/akun1.jpg" },
  { id: 2, nama: "Akun Starter Pack", harga: "Rp 250.000", deskripsi: "Level 10, cocok untuk pemula.", gambar: "assets/akun2.jpg" },
  { id: 3, nama: "Akun Epic Legend", harga: "Rp 3.000.000", deskripsi: "Full squad epic, cocok buat turnamen.", gambar: "assets/akun3.jpg" },
  { id: 4, nama: "Akun Garcia 🔥", harga: "Rp 750.000", deskripsi: "Level 20, punya beberapa pemain epic + koin 5.000. Cocok buat push rank.", gambar: "assets/akun1.jpg" }
];